import * as React from "react";

declare const MDBFreeBird: React.FunctionComponent<{
  className?: string;
  tag?: string;
  [rest: string]: any;
}>;

export default MDBFreeBird;
