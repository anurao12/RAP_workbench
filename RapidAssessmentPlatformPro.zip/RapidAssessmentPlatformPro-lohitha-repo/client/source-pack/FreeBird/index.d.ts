export { default } from './FreeBird';
export * from './FreeBird';