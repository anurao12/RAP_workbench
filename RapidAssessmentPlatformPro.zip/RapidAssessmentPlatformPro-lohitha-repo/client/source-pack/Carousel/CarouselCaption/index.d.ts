export { default } from './CarouselCaption';
export * from './CarouselCaption';