export { default } from './CarouselIndicator';
export * from './CarouselIndicator';