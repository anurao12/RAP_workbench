import * as React from "react";

declare class MDBTabPane extends React.Component<{
  activeItemId?: any;
  className?: string;
  tabId?: any;
  [rest: string]: any;
}, any> {}

export default MDBTabPane;
