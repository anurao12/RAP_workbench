export { default } from './Footer';
export * from './Footer';