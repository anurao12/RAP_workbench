export { default } from './InputNumeric';
export * from './InputNumeric';