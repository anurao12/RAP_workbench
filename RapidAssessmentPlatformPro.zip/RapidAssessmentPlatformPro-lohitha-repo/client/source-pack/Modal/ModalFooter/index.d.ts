export { default } from './ModalFooter';
export * from './ModalFooter';