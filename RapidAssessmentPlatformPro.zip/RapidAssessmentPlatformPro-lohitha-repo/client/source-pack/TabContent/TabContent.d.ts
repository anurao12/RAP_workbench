import * as React from "react";

declare class MDBTabContent extends React.Component<{
  activeItem?: any;
  tabId?: any;
  className?: string;
  [rest: string]: any;
}, any> {}

export default MDBTabContent;
