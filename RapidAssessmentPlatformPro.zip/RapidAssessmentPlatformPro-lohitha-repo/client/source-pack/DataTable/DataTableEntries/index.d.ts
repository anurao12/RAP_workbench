export { default } from './DataTableEntries';
export * from './DataTableEntries';