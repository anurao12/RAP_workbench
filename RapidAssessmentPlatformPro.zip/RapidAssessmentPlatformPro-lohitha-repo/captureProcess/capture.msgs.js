module.exports = {
    SuccessfulCapture: 'Your Process has been Captured Successfully!!',
 } 